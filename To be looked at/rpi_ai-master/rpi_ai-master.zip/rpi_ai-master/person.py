class Person(object):
	def __init__(self, name=None, job=None, greeting=None, lastSeen=None, gender=None):
		self.name = name
		self.job = job
		self.greeting = greeting
		self.lastSeen = lastSeen
		self.gender = gender
		print