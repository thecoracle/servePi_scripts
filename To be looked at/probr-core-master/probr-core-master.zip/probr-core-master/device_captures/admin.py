from django.contrib import admin
from models import DeviceCapture

admin.site.register(DeviceCapture)
