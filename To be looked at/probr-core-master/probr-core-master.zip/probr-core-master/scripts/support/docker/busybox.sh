#!/usr/bin/env bash

# Official Container: https://hub.docker.com/_/busybox/
# Requires ~2.5 MB
docker run -it --rm busybox
