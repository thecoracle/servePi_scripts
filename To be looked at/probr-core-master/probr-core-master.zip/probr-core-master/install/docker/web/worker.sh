#!/bin/sh

celery worker -A probr
