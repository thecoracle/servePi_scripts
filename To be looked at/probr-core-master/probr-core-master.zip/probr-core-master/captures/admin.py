from django.contrib import admin
from models import Capture

admin.site.register(Capture)
# Register your models here.
