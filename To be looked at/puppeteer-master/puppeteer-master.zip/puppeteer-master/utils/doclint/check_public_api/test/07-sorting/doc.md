### class: Foo

#### event: 'c'

#### event: 'a'

#### foo.aaa()

#### event: 'b'

#### foo.ddd

#### new Foo()

#### foo.ccc()

#### foo.bbb()
