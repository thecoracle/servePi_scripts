### class: Foo
#### new Foo(arg1, arg2)
- `arg1` <[string]>
- `arg2` <[string]>

#### foo.bar(options)
- `options` <[Object]>

#### foo.test(...files)
- `...filePaths` <[string]>

