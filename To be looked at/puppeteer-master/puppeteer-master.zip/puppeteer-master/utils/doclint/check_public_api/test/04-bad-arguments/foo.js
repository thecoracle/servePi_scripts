class Foo {
  constructor(arg1, arg3 = {}) {
  }

  test(...filePaths) {
  }

  bar({visibility}) {
  }
}
