# tepferpiano

A real-time player piano that follows different algorithms. This code was inspired by [this article about Dan Tepfer's programming of his player piano](http://www.npr.org/2017/07/24/538677517/fascinating-algorithm-dan-tepfers-player-piano-is-his-composing-partner).
